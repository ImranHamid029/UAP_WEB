<?php
include 'koneksi.php';

if (isset($_POST['submit'])) {
    $nama_kucing = $_POST['nama_kucing'];
    $ras_kucing = $_POST['ras_kucing'];
    $umur_kucing = $_POST['umur_kucing'];
    $harga_kucing = $_POST['harga_kucing'];


    $query = "INSERT INTO daftar_kucing (nama_kucing,ras_kucing,umur_kucing,harga_kucing) VALUES ('$nama_kucing', '$ras_kucing','$umur_kucing' ,'$harga_kucing')";
    if (mysqli_query($conn, $query)) {
        echo "Data baru berhasil ditambahkan.";
        echo "<a href='daftar_kucing.php'>Tampilkan Data</a>";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}
?>
