<?php
include 'koneksi.php';

if (isset($_POST['submit'])) {
    $nama_pemilik = $_POST['nama_pemilik'];
    $nama_kucing = $_POST['nama_kucing'];
    $ras_kucing = $_POST['ras_kucing'];
    $umur_kucing = $_POST['umur_kucing'];
    $tanggal_masuk = $_POST['tanggal_masuk'];
    $tanggal_keluar = $_POST['tanggal_keluar'];
    $biaya = $_POST['biaya'];
    $id_kandang = $_POST['id_kandang'];

    // Check if id_kandang is unique
    $check_query = "SELECT * FROM penitipan_kucing WHERE id_kandang = '$id_kandang'";
    $check_result = mysqli_query($conn, $check_query);

    if (mysqli_num_rows($check_result) > 0) {
        echo "<script>
                window.alert('kandang telah terisi');
            </script>";
    } else {
        $query = "INSERT INTO penitipan_kucing (nama_pemilik, nama_kucing, ras_kucing, umur_kucing, tanggal_masuk, tanggal_keluar, biaya, id_kandang) 
                  VALUES ('$nama_pemilik', '$nama_kucing', '$ras_kucing', '$umur_kucing', '$tanggal_masuk', '$tanggal_keluar', '$biaya', '$id_kandang')";

        if (mysqli_query($conn, $query)) {
            header("Location: penitipan_kucing.php");
        } else {
            echo "Error: " . $query . "<br>" . mysqli_error($conn);
        }
    }

    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Data Penitipan Kucing</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .form-container {
            background-color: #fff;
            padding: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-radius: 8px;
            max-width: 500px;
            width: 100%;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"], input[type="number"], input[type="date"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .submit-button {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            display: block;
            width: 100%;
            text-align: center;
        }

        .submit-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Tambah Data Penitipan Kucing</h1>
        <form action="" method="post">
            <label for="nama_pemilik">Nama Pemilik:</label>
            <input type="text" id="nama_pemilik" name="nama_pemilik" required>

            <label for="nama_kucing">Nama Kucing:</label>
            <input type="text" id="nama_kucing" name="nama_kucing" required>

            <label for="ras_kucing">Ras Kucing:</label>
            <input type="text" id="ras_kucing" name="ras_kucing" required>

            <label for="umur_kucing">Umur Kucing:</label>
            <input type="text" id="umur_kucing" name="umur_kucing" required>

            <label for="tanggal_masuk">Tanggal Masuk:</label>
            <input type="date" id="tanggal_masuk" name="tanggal_masuk" required>

            <label for="tanggal_keluar">Tanggal Keluar:</label>
            <input type="date" id="tanggal_keluar" name="tanggal_keluar" required>

            <label for="biaya">Biaya:</label>
            <input type="number" id="biaya" name="biaya" required>

            <label for="id_kandang">ID Kandang:</label>
            <input type="number" id="id_kandang" name="id_kandang" required>

            <button type="submit" name="submit" class="submit-button">Tambah</button>
        </form>
    </div>
</body>
</html>
