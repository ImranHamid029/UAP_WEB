<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Kucing</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
        }

        .container {
            max-width: 100%;
            margin: 0 auto;
            background-color: #fff;
            padding: 20px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }

        h1 {
            text-align: center;
            color: #333;
        }

        .table-container {
            display: flex;
            flex-direction: column;
            align-items: flex-start;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            margin: 20px 0;
        }

        table, th, td {
            border: 1px solid #ddd;
        }

        th, td {
            padding: 12px;
            text-align: left;
        }

        th {
            background-color: #4CAF50;
            color: white;
        }

        tr:nth-child(even) {
            background-color: #f2f2f2;
        }

        tr:hover {
            background-color: #ddd;
        }

        .button {
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            text-decoration: none;
            color: white;
            cursor: pointer;
            display: inline-block;
        }

        .add-button {
            background-color: #4CAF50;
            margin-bottom: 20px;
            margin-left:1640px;
        }

        .add-button:hover {
            background-color: #45a049;
        }

        .edit-button {
            background-color: #f0ad4e;
        }

        .edit-button:hover {
            background-color: #ec971f;
        }

        .delete-button {
            background-color: #d9534f;
        }

        .delete-button:hover {
            background-color: #c9302c;
        }

        .action-buttons {
            display: flex;
            gap: 10px;
        }
        
        .back-button{
            background-color: #4CAF50;
            margin-bottom: 20px;

        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Daftar Kucing</h1>
        <div class="table-container">
            <table>
                <tr>
                    <th>Id</th>
                    <th>Nama Kucing</th>
                    <th>Ras Kucing</th>
                    <th>Umur Kucing</th>
                    <th>Harga</th>
                    <th>Aksi</th>
                </tr>

                <?php
                include 'koneksi.php';

                $query = "SELECT * FROM daftar_kucing";
                $result = mysqli_query($conn, $query);

                if (mysqli_num_rows($result) > 0) {
                    while($row = mysqli_fetch_assoc($result)) {
                        echo "<tr>
                                <td>" . $row["id_kucing"]. "</td>
                                <td>" . $row["nama_kucing"]. "</td>
                                <td>" . $row["ras_kucing"]. "</td>
                                <td>" . $row["umur_kucing"]. "</td>
                                <td>" . $row["harga_kucing"]. "</td>
                                <td class='action-buttons'>
                                    <a href='edit.php?id=" . $row["id_kucing"] . "' class='button edit-button'>Edit</a>
                                    <a href='delete.php?id=" . $row["id_kucing"] . "' class='button delete-button' onclick=\"return confirmDelete(" . $row["id_kucing"] . ");\">Delete</a>
                                </td>
                              </tr>";
                    }
                } else {
                    echo "<tr><td colspan='6'>0 results</td></tr>";
                }
                ?>
            </table>
            <a href="add.html" class="button add-button">Tambah Data Kucing</a>
            <a href="home_page.html" class="button back-button">Kembali</a>
        </div>
    </div>
</body>
</html>
