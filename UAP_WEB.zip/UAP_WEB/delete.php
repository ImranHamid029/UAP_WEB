<?php
include 'koneksi.php';

if(isset($_GET['id'])) {
    $id_kucing = mysqli_real_escape_string($conn, $_GET['id']);

    $query = "DELETE FROM daftar_kucing WHERE id_kucing = '$id_kucing'";
    
    if(mysqli_query($conn, $query)) {
        // Jika data berhasil dihapus
        echo "<script>
                var confirmed = confirm('apakah ingin menghapus data ini?');
                if(confirmed) {
                    window.alert('data berhasil di hapus');
                    window.location.href = 'daftar_kucing.php';
                } else {
                    window.history.back(); 
                }
              </script>";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    header("Location: daftar_kucing.php");
    exit();
}
?>
