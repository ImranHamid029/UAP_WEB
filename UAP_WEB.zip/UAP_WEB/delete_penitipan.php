<?php
include 'koneksi.php';

if(isset($_GET['id'])) {
    $id_penitipan = mysqli_real_escape_string($conn, $_GET['id']);

    $query = "DELETE FROM penitipan_kucing WHERE id_penitipan = '$id_penitipan'";
    
    if(mysqli_query($conn, $query)) {
        // Jika data berhasil dihapus
        echo "<script>
                var confirmed = confirm('apakah ingin menghapus data ini?');
                if(confirmed) {
                    window.alert('data berhasil di hapus');
                    window.location.href = 'penitipan_kucing.php';
                } else {
                    window.history.back(); 
                }
              </script>";
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }

    mysqli_close($conn);
} else {
    header("Location: penitipan_kucing.php");
    exit();
}
?>
