<?php
include 'koneksi.php';

$id = $_GET['id'];
$query = "SELECT * FROM daftar_kucing WHERE id_kucing = $id";
$result = mysqli_query($conn, $query);

if (mysqli_num_rows($result) > 0) {
    $row = mysqli_fetch_assoc($result);
} else {
    echo "Data tidak ditemukan.";
    exit;
}

if (isset($_POST['submit'])) {
    $nama_kucing = $_POST['nama_kucing'];
    $ras_kucing = $_POST['ras_kucing'];
    $umur_kucing = $_POST['umur_kucing'];
    $harga_kucing = $_POST['harga_kucing'];

    $query = "UPDATE daftar_kucing SET nama_kucing='$nama_kucing', ras_kucing='$ras_kucing', umur_kucing='$umur_kucing', harga_kucing='$harga_kucing' WHERE id_kucing=$id";

    if (mysqli_query($conn, $query)) {
        header("Location: daftar_kucing.php");
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($conn);
    }
}

mysqli_close($conn);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Data Kucing</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }

        .form-container {
            background-color: #fff;
            padding: 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            border-radius: 8px;
            max-width: 500px;
            width: 100%;
        }

        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }

        label {
            display: block;
            margin-bottom: 10px;
            font-weight: bold;
        }

        input[type="text"], input[type="number"] {
            width: calc(100% - 20px);
            padding: 10px;
            margin-bottom: 20px;
            border: 1px solid #ddd;
            border-radius: 4px;
        }

        .submit-button {
            background-color: #4CAF50;
            color: #fff;
            padding: 10px 15px;
            border: none;
            border-radius: 4px;
            cursor: pointer;
            font-size: 16px;
            display: block;
            width: 100%;
            text-align: center;
        }

        .submit-button:hover {
            background-color: #45a049;
        }
    </style>
</head>
<body>
    <div class="form-container">
        <h1>Edit Data Kucing</h1>
        <form action="" method="post">
            <label for="nama_kucing">Nama Kucing:</label>
            <input type="text" id="nama_kucing" name="nama_kucing" value="<?php echo $row['nama_kucing']; ?>" required>

            <label for="ras_kucing">Ras Kucing:</label>
            <input type="text" id="ras_kucing" name="ras_kucing" value="<?php echo $row['ras_kucing']; ?>" required>

            <label for="umur_kucing">Umur Kucing:</label>
            <input type="text" id="umur_kucing" name="umur_kucing" value="<?php echo $row['umur_kucing']; ?>" required>

            <label for="harga_kucing">Harga Kucing:</label>
            <input type="number" id="harga_kucing" name="harga_kucing" value="<?php echo $row['harga_kucing']; ?>" required>

            <button type="submit" name="submit" class="submit-button">Update</button>
        </form>
    </div>
</body>
</html>
