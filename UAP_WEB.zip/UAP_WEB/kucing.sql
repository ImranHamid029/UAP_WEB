-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jun 07, 2024 at 01:16 PM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kucing`
--

-- --------------------------------------------------------

--
-- Table structure for table `daftar_kucing`
--

CREATE TABLE `daftar_kucing` (
  `id_kucing` int(10) NOT NULL,
  `nama_kucing` varchar(255) DEFAULT NULL,
  `ras_kucing` varchar(255) DEFAULT NULL,
  `umur_kucing` varchar(255) DEFAULT NULL,
  `harga_kucing` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kandang`
--

CREATE TABLE `kandang` (
  `id_kandang` int(10) NOT NULL,
  `no_kandang` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `kandang`
--

INSERT INTO `kandang` (`id_kandang`, `no_kandang`) VALUES
(1, 1),
(2, 2),
(3, 3),
(4, 4),
(5, 5);

-- --------------------------------------------------------

--
-- Table structure for table `penitipan_kucing`
--

CREATE TABLE `penitipan_kucing` (
  `id_penitipan` int(10) NOT NULL,
  `nama_pemilik` varchar(255) DEFAULT NULL,
  `nama_kucing` varchar(255) DEFAULT NULL,
  `ras_kucing` varchar(255) DEFAULT NULL,
  `umur_kucing` varchar(255) DEFAULT NULL,
  `no_hp` varchar(12) DEFAULT NULL,
  `tanggal_masuk` date DEFAULT NULL,
  `tanggal_keluar` date DEFAULT NULL,
  `biaya` varchar(255) DEFAULT NULL,
  `id_kandang` int(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `penitipan_kucing`
--

INSERT INTO `penitipan_kucing` (`id_penitipan`, `nama_pemilik`, `nama_kucing`, `ras_kucing`, `umur_kucing`, `no_hp`, `tanggal_masuk`, `tanggal_keluar`, `biaya`, `id_kandang`) VALUES
(2, 'akmal', 'joeee', 'persian', '2 bulan', NULL, '2024-06-04', '2024-06-08', '400000', 2);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `daftar_kucing`
--
ALTER TABLE `daftar_kucing`
  ADD PRIMARY KEY (`id_kucing`);

--
-- Indexes for table `kandang`
--
ALTER TABLE `kandang`
  ADD PRIMARY KEY (`id_kandang`);

--
-- Indexes for table `penitipan_kucing`
--
ALTER TABLE `penitipan_kucing`
  ADD PRIMARY KEY (`id_penitipan`),
  ADD KEY `fk_kandang` (`id_kandang`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `daftar_kucing`
--
ALTER TABLE `daftar_kucing`
  MODIFY `id_kucing` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `penitipan_kucing`
--
ALTER TABLE `penitipan_kucing`
  MODIFY `id_penitipan` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `penitipan_kucing`
--
ALTER TABLE `penitipan_kucing`
  ADD CONSTRAINT `fk_kandang` FOREIGN KEY (`id_kandang`) REFERENCES `kandang` (`id_kandang`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
